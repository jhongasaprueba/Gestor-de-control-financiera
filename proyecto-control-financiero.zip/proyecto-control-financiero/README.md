# Proyecto Control Financiero

## Estructura
- **docs/** — las reglas del negocio: entidades, catálogo de movimientos, tipos de operación, plan de cuentas, glosario y FAQ. Esta es la fuente de verdad de *cómo funciona el negocio*. Léela antes de tocar el código.
- **backend/** — el esquema de base de datos (`schema.sql`) y el bot de Telegram (`bot.ts`), más el guion de la conversación del bot (`flujo-bot.md`).

## Cómo continuar en Claude Code
1. Abre esta carpeta como proyecto.
2. Corre `backend/schema.sql` en el proyecto de Supabase (crea las tablas y vistas).
3. Pide que se complete `backend/bot.ts` siguiendo `backend/flujo-bot.md` (varias ramas del flujo de `/nuevomovimiento` están marcadas con `TODO`).
4. Despliega `bot.ts` como Supabase Edge Function y registra el webhook con el token de Telegram (ya lo tienes de BotFather).
5. Cualquier duda sobre una regla de negocio (qué es una CxP, cuándo se cierra una deuda, qué campos son obligatorios) está en `docs/`, no hay que volver a explicarla.

## Nota
`Control_Financiero.xlsx` (la versión en Google Sheets) queda como referencia/respaldo, pero la fuente de datos real pasa a ser Supabase.
