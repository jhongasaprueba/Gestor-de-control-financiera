# Flujo del Bot de Telegram — Control Financiero
Diseño conversacional completo: qué pregunta el bot, en qué orden, y qué valida antes de guardar. Usar cuando: se vaya a construir o revisar la lógica del bot en Claude Code.

## Seguridad
El bot solo responde al `chat_id` del dueño (una sola persona opera). Cualquier otro `chat_id` recibe "No autorizado" y no se procesa nada. El ID autorizado vive en una variable de entorno (`TELEGRAM_ALLOWED_CHAT_ID`), nunca hardcodeado.

## Comandos de consulta (responden al instante, sin conversación)

| Comando | Qué hace | De dónde saca el dato |
|---|---|---|
| `/saldo` | Saldo de las 3 cajas | `v_cajas` |
| `/debo` | Cuentas por pagar pendientes (proveedor USDT + procesador), por moneda | `v_cxp` |
| `/mecobo` | Cuentas por cobrar pendientes, por cliente y moneda | `v_cxc` |
| `/utilidad` | Utilidad acumulada de todas las operaciones | `v_operaciones` |
| `/resumen` | Los cuatro anteriores en un solo mensaje | `v_dashboard` |

## Comandos de registro (inician una conversación paso a paso)

### `/nuevomovimiento`
1. **Tipo** — botones: `Entrada` / `Salida` / `Transferencia`
2. **Subtipo** — botones filtrados según el Tipo elegido (ej. si Tipo=Salida, solo muestra: Pago proveedor, Compra mercancía, Pago préstamo, Envío a procesador, COP a USD, COP a USDT, USD a USDT, Entre cajas)
3. **Rama según Subtipo:**
   - **Si es conversión de moneda** (`COP a USDT`, `COP a USD`, `USD a USDT`):
     a. Pide **Cantidad** (cuánto se compra)
     b. Pide **Tasa_Cambio** (precio por unidad)
     c. Pregunta "¿Tuvo costo de procesador?" [Sí/No] → si Sí, pide **Costo_Pct**
     d. Calcula `Monto = Cantidad × Tasa_Cambio × (1 + Costo_Pct)` y lo muestra: *"Vas a pagar $99.495.000 COP. ¿Confirmas?"*
   - **Si NO es conversión** (recaudo, pago, envío a procesador, etc.):
     a. Pide **Monto** directamente
4. Pide **Tercero** — botones con la lista de `terceros` (filtrada: si Subtipo="Recaudo cliente" solo muestra clientes; si es pago a proveedor/procesador solo muestra esos)
5. Pide **Caja_Afectada** — botones: `Caja COP` / `Caja USD` / `Caja USDT`
6. Pregunta **¿Vincular a una operación?** [Sí/No] → si Sí, pide el código (autocompletar con operaciones abiertas)
7. Pregunta **Soporte** (opcional: link o "ninguno")
8. Muestra resumen completo y pide confirmación final [Confirmar/Cancelar]
9. Inserta en `movimientos` y responde con el nuevo saldo de la caja afectada

El bot **no avanza al siguiente paso si falta un campo obligatorio** — a diferencia de un desplegable en Sheets, aquí es imposible guardar un movimiento incompleto.

### `/nuevaoperacion`
1. Cliente (botones desde `terceros` tipo=cliente, o "Nuevo cliente" para agregarlo)
2. Tipo de operación [1–5] (con descripción corta de cada uno)
3. USD_Mercancia
4. Tasa_Compra_USDT
5. ¿Costo de procesador? [Sí/No] → Costo_Procesador_Pct
6. Tasa_Venta_Cliente
7. Calcula y muestra: Costo total, Monto a cobrar, **Utilidad** — pide confirmación
8. Inserta en `operaciones` y pregunta "¿Generar automáticamente la Cuenta por Cobrar del cliente?" [Sí/No]

### `/nuevoabono`
1. Pide el código de CxC (autocompletar con las que tienen `saldo_pendiente > 0`, mostrando cliente y saldo)
2. Monto del abono (el bot avisa si el monto supera el saldo pendiente y pide confirmar o corregir)
3. Medio de pago — botones: `Transferencia bancaria` / `Efectivo` / `USDT`
4. Fecha (por defecto hoy)
5. Confirma e inserta en `abonos`, responde con el nuevo saldo pendiente de esa CxC

## Manejo de estado
Como la función que atiende el webhook de Telegram no tiene memoria entre mensajes, cada paso de estos flujos se guarda en la tabla `bot_conversaciones` (`chat_id`, `flujo`, `paso`, `datos` en JSON). Al recibir un mensaje, el bot primero revisa si hay una conversación en curso para ese `chat_id`; si la hay, continúa desde el `paso` guardado. Al confirmar o cancelar, se borra la fila.

## Manejo de errores
- Si el usuario escribe texto donde se esperaba un número, el bot repite la pregunta sin avanzar.
- Si cancela a mitad de camino (`/cancelar`), se borra la conversación en curso sin insertar nada.
- Cualquier inserción fallida (por una restricción de la base de datos) se le muestra al usuario en lenguaje simple, no el error técnico crudo.
