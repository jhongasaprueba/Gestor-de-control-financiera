// Supabase Edge Function — Webhook del bot de Telegram
// Punto de partida: implementa /saldo, /debo, /mecobo, /utilidad, /resumen
// completos, y el esqueleto del flujo /nuevomovimiento (una rama de ejemplo).
// Claude Code debe completar las ramas faltantes siguiendo flujo-bot.md.
//
// Variables de entorno requeridas (Supabase → Project Settings → Edge Functions):
//   TELEGRAM_BOT_TOKEN        (el token que ya tienes de BotFather)
//   TELEGRAM_ALLOWED_CHAT_ID  (tu chat_id — solo tú puedes usar el bot)
//   SUPABASE_URL
//   SUPABASE_SERVICE_ROLE_KEY

import { Bot, webhookCallback, InlineKeyboard } from "https://deno.land/x/grammy@v1.21.1/mod.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN")!;
const ALLOWED_CHAT_ID = Number(Deno.env.get("TELEGRAM_ALLOWED_CHAT_ID"));
const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const bot = new Bot(BOT_TOKEN);
const fmt = (n: number) => new Intl.NumberFormat("es-CO").format(Math.round(n));

// ---------------------------------------------------------------------------
// Seguridad: solo el chat autorizado pasa de aquí
// ---------------------------------------------------------------------------
bot.use(async (ctx, next) => {
  if (ctx.chat?.id !== ALLOWED_CHAT_ID) {
    await ctx.reply("No autorizado.");
    return;
  }
  await next();
});

// ---------------------------------------------------------------------------
// Consultas (sin conversación, responden directo desde las vistas)
// ---------------------------------------------------------------------------
bot.command("saldo", async (ctx) => {
  const { data, error } = await supabase.from("v_cajas").select("*");
  if (error) return ctx.reply("Error consultando saldos: " + error.message);
  const lineas = data.map((c) => `${c.caja}: $${fmt(c.saldo)}`);
  await ctx.reply("💰 Saldos actuales\n" + lineas.join("\n"));
});

bot.command("debo", async (ctx) => {
  const { data, error } = await supabase
    .from("v_cxp")
    .select("*")
    .eq("estado", "Pendiente");
  if (error) return ctx.reply("Error: " + error.message);
  if (!data.length) return ctx.reply("No tienes cuentas por pagar pendientes.");
  const lineas = data.map((d) => `• ${d.tipo_deuda} — ${d.moneda} ${fmt(d.monto)}`);
  await ctx.reply("📤 Cuentas por pagar pendientes\n" + lineas.join("\n"));
});

bot.command("mecobo", async (ctx) => {
  const { data, error } = await supabase
    .from("v_cxc")
    .select("*")
    .gt("saldo_pendiente", 0);
  if (error) return ctx.reply("Error: " + error.message);
  if (!data.length) return ctx.reply("No tienes cuentas por cobrar pendientes.");
  const lineas = data.map(
    (d) => `• ${d.codigo} — ${d.moneda} ${fmt(d.saldo_pendiente)} pendiente (${d.estado})`,
  );
  await ctx.reply("📥 Cuentas por cobrar pendientes\n" + lineas.join("\n"));
});

bot.command("utilidad", async (ctx) => {
  const { data, error } = await supabase.from("v_operaciones").select("utilidad_cop");
  if (error) return ctx.reply("Error: " + error.message);
  const total = data.reduce((s, o) => s + (o.utilidad_cop ?? 0), 0);
  await ctx.reply(`📈 Utilidad acumulada: $${fmt(total)} COP`);
});

bot.command("resumen", async (ctx) => {
  const { data, error } = await supabase.from("v_dashboard").select("*").single();
  if (error) return ctx.reply("Error: " + error.message);
  await ctx.reply(
    `📊 Resumen\n\n` +
      `Caja COP: $${fmt(data.saldo_cop)}\n` +
      `Caja USD: $${fmt(data.saldo_usd)}\n` +
      `Caja USDT: ${fmt(data.saldo_usdt)}\n\n` +
      `Me deben (COP): $${fmt(data.cxc_pendiente_cop)}\n` +
      `Me deben (USDT): ${fmt(data.cxc_pendiente_usdt)}\n\n` +
      `Debo (COP): $${fmt(data.cxp_pendiente_cop)}\n` +
      `Debo (USDT): ${fmt(data.cxp_pendiente_usdt)}\n\n` +
      `Utilidad acumulada: $${fmt(data.utilidad_acumulada_cop)}`,
  );
});

// ---------------------------------------------------------------------------
// /nuevomovimiento — esqueleto del flujo paso a paso (ver flujo-bot.md)
// Ejemplo completo solo para la rama Tipo=Salida, Subtipo=COP a USDT.
// Claude Code debe replicar este patrón para el resto de subtipos.
// ---------------------------------------------------------------------------
bot.command("nuevomovimiento", async (ctx) => {
  await supabase.from("bot_conversaciones").upsert({
    chat_id: ctx.chat.id,
    flujo: "nuevo_movimiento",
    paso: "tipo",
    datos: {},
  });
  const kb = new InlineKeyboard()
    .text("Entrada", "tipo:Entrada")
    .text("Salida", "tipo:Salida")
    .text("Transferencia", "tipo:Transferencia");
  await ctx.reply("¿Qué tipo de movimiento?", { reply_markup: kb });
});

bot.callbackQuery(/^tipo:(.+)$/, async (ctx) => {
  const tipo = ctx.match[1];
  await supabase
    .from("bot_conversaciones")
    .update({ paso: "subtipo", datos: { tipo } })
    .eq("chat_id", ctx.chat!.id);

  // TODO (Claude Code): filtrar subtipos según `tipo`, tal como describe flujo-bot.md
  const kb = new InlineKeyboard()
    .text("COP a USDT", "subtipo:COP a USDT")
    .row()
    .text("Envío a procesador", "subtipo:Envío a procesador");
  await ctx.editMessageText("¿Cuál subtipo?", { reply_markup: kb });
});

bot.callbackQuery(/^subtipo:(.+)$/, async (ctx) => {
  const subtipo = ctx.match[1];
  const { data: conv } = await supabase
    .from("bot_conversaciones")
    .select("datos")
    .eq("chat_id", ctx.chat!.id)
    .single();
  const datos = { ...conv?.datos, subtipo };

  const esConversion = ["COP a USD", "COP a USDT", "USD a USDT"].includes(subtipo);
  await supabase
    .from("bot_conversaciones")
    .update({ paso: esConversion ? "cantidad" : "monto", datos })
    .eq("chat_id", ctx.chat!.id);

  await ctx.editMessageText(
    esConversion
      ? "¿Cuántas unidades vas a comprar? (ej. cantidad de USDT)"
      : "¿Cuál es el monto?",
  );
});

// Mensajes de texto libres: siguiente paso de la conversación en curso
bot.on("message:text", async (ctx) => {
  const { data: conv } = await supabase
    .from("bot_conversaciones")
    .select("*")
    .eq("chat_id", ctx.chat.id)
    .maybeSingle();
  if (!conv) return; // no hay conversación activa, ignorar

  const texto = ctx.message.text.trim();

  if (conv.paso === "cantidad") {
    const cantidad = Number(texto);
    if (isNaN(cantidad)) return ctx.reply("Escribe solo el número, por favor.");
    await supabase
      .from("bot_conversaciones")
      .update({ paso: "tasa_cambio", datos: { ...conv.datos, cantidad } })
      .eq("chat_id", ctx.chat.id);
    return ctx.reply("¿A qué tasa? (precio por unidad)");
  }

  if (conv.paso === "tasa_cambio") {
    const tasa_cambio = Number(texto);
    if (isNaN(tasa_cambio)) return ctx.reply("Escribe solo el número, por favor.");
    const datos = { ...conv.datos, tasa_cambio, costo_pct: 0 };
    const monto = datos.cantidad * tasa_cambio * (1 + datos.costo_pct);
    await supabase
      .from("bot_conversaciones")
      .update({ paso: "confirmar", datos: { ...datos, monto } })
      .eq("chat_id", ctx.chat.id);
    return ctx.reply(
      `Vas a pagar $${fmt(monto)}. ¿Confirmas?\n\n` +
        "(TODO: agregar botones Confirmar/Cancelar y luego el resto de campos " +
        "— tercero, caja afectada, operación, soporte — antes de insertar en `movimientos`, " +
        "siguiendo flujo-bot.md paso a paso)",
    );
  }

  // TODO (Claude Code): pasos "monto", "tercero", "caja_afectada",
  // "vincular_operacion", "soporte", "confirmar" — insertar en `movimientos`
  // al confirmar y borrar la fila de bot_conversaciones.
});

bot.command("cancelar", async (ctx) => {
  await supabase.from("bot_conversaciones").delete().eq("chat_id", ctx.chat.id);
  await ctx.reply("Cancelado.");
});

export default webhookCallback(bot, "std/http");
