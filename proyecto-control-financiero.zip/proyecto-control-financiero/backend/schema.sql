-- ============================================================================
-- Esquema de Control Financiero — Supabase (Postgres)
-- Reemplaza el libro de Google Sheets: mismas entidades, ahora como tablas
-- reales con reglas que la base de datos hace cumplir (no fórmulas frágiles).
-- ============================================================================

-- ---------------------------------------------------------------------------
-- TERCEROS (clientes, proveedores de USDT, procesadores, fabricantes, etc.)
-- ---------------------------------------------------------------------------
create table terceros (
  id serial primary key,
  nombre text not null unique,
  tipo text not null check (tipo in
    ('proveedor_usdt', 'procesador', 'cliente', 'fabricante', 'prestamista'))
);

insert into terceros (nombre, tipo) values
  ('Facu', 'procesador'),
  ('Richi', 'procesador'),
  ('Bayter', 'proveedor_usdt'),
  ('Lider', 'proveedor_usdt'),
  ('Roma', 'proveedor_usdt'),
  ('Rojo', 'proveedor_usdt'),
  ('Tello', 'proveedor_usdt');

-- ---------------------------------------------------------------------------
-- OPERACIONES (un ciclo compra-venta completo)
-- ---------------------------------------------------------------------------
create table operaciones (
  id serial primary key,
  codigo text not null unique,             -- OP-0001
  fecha date not null default current_date,
  cliente_id int references terceros(id),
  tipo int not null check (tipo between 1 and 5),
  usd_mercancia numeric,
  tasa_compra_usdt numeric,
  costo_procesador_pct numeric,
  tasa_venta_cliente numeric,
  estado text not null default 'Cotizada' check (estado in
    ('Cotizada', 'Aceptada', 'En proceso', 'Pagada', 'Conciliada', 'Cerrada', 'Rechazada')),
  creado_en timestamptz default now()
);

-- Utilidad calculada, nunca guardada a mano
create view v_operaciones as
select
  o.*,
  usd_mercancia * tasa_compra_usdt * (1 + costo_procesador_pct)      as costo_total_cop,
  usd_mercancia * tasa_venta_cliente                                  as monto_cobrado_cliente_cop,
  (usd_mercancia * tasa_venta_cliente)
    - (usd_mercancia * tasa_compra_usdt * (1 + costo_procesador_pct)) as utilidad_cop
from operaciones o;

-- ---------------------------------------------------------------------------
-- MOVIMIENTOS (el libro diario — única tabla donde se inserta a mano)
-- ---------------------------------------------------------------------------
create table movimientos (
  id serial primary key,
  fecha date not null default current_date,
  tipo text not null check (tipo in ('Entrada', 'Salida', 'Transferencia')),
  subtipo text not null check (subtipo in (
    'Recaudo cliente', 'Compra de USDT recibida', 'Préstamo recibido',
    'Pago proveedor', 'Compra mercancía', 'Pago préstamo', 'Envío a procesador',
    'COP a USD', 'COP a USDT', 'USD a USDT', 'Entre cajas')),
  operacion_id int references operaciones(id),
  tercero_id int references terceros(id),
  moneda text not null check (moneda in ('COP', 'USD', 'USDT')),
  -- Solo se llenan en movimientos de compra/cambio de moneda:
  cantidad numeric,
  tasa_cambio numeric,
  costo_pct numeric,
  -- Monto: para conversiones se calcula en la app antes de insertar
  -- (cantidad * tasa_cambio * (1 + costo_pct)); para el resto se escribe directo.
  monto numeric not null check (monto > 0),
  caja_afectada text not null check (caja_afectada in ('Caja COP', 'Caja USD', 'Caja USDT')),
  soporte text,
  estado text not null default 'Confirmado' check (estado in ('Confirmado', 'Pendiente')),
  notas text,
  creado_en timestamptz default now(),
  -- Regla: si el subtipo es de cambio de moneda, cantidad y tasa son obligatorias
  constraint chk_conversion_requiere_tasa check (
    (subtipo in ('COP a USD', 'COP a USDT', 'USD a USDT')
       and cantidad is not null and tasa_cambio is not null)
    or subtipo not in ('COP a USD', 'COP a USDT', 'USD a USDT')
  )
);

create index idx_movimientos_operacion on movimientos(operacion_id);
create index idx_movimientos_caja on movimientos(caja_afectada);

-- Saldos de caja: siempre exactos, nunca una celda desactualizada
create view v_cajas as
select
  caja_afectada as caja,
  coalesce(sum(monto) filter (where tipo = 'Entrada'), 0) as total_entradas,
  coalesce(sum(monto) filter (where tipo = 'Salida'), 0)  as total_salidas,
  coalesce(sum(monto) filter (where tipo = 'Entrada'), 0)
    - coalesce(sum(monto) filter (where tipo = 'Salida'), 0) as saldo
from movimientos
group by caja_afectada;

-- ---------------------------------------------------------------------------
-- CUENTAS POR COBRAR (maestro + abonos, hasta 4 pagos parciales)
-- ---------------------------------------------------------------------------
create table cxc_maestro (
  id serial primary key,
  codigo text not null unique,             -- CXC-0001
  operacion_id int references operaciones(id),
  cliente_id int not null references terceros(id),
  moneda text not null check (moneda in ('COP', 'USD', 'USDT')),
  monto_total numeric not null check (monto_total > 0),
  fecha_operacion date not null default current_date
);

create table abonos (
  id serial primary key,
  codigo text not null unique,             -- AB-0001
  cxc_id int not null references cxc_maestro(id),
  fecha_abono date not null default current_date,
  monto numeric not null check (monto > 0),
  medio_pago text not null check (medio_pago in ('Transferencia bancaria', 'Efectivo', 'USDT')),
  soporte text,
  notas text
);

create view v_cxc as
select
  m.*,
  coalesce(a.total_abonado, 0) as total_abonado,
  m.monto_total - coalesce(a.total_abonado, 0) as saldo_pendiente,
  case
    when m.monto_total - coalesce(a.total_abonado, 0) = 0 then 'Pagado'
    when coalesce(a.total_abonado, 0) = 0 then 'Pendiente'
    else 'Parcial'
  end as estado
from cxc_maestro m
left join (
  select cxc_id, sum(monto) as total_abonado from abonos group by cxc_id
) a on a.cxc_id = m.id;

-- ---------------------------------------------------------------------------
-- CUENTAS POR PAGAR (pago único: proveedor de USDT o procesador)
-- ---------------------------------------------------------------------------
create table cxp (
  id serial primary key,
  codigo text not null unique,             -- CXP-0001
  operacion_id int references operaciones(id),
  tercero_id int not null references terceros(id),
  moneda text not null check (moneda in ('COP', 'USD', 'USDT')),
  tipo_deuda text not null check (tipo_deuda in ('Proveedor USDT', 'Pago en tránsito con procesador')),
  monto numeric not null check (monto > 0),
  mt103_utr text,
  fecha_generacion date not null default current_date,
  fecha_cierre date
);

create view v_cxp as
select *,
  case when fecha_cierre is null then 'Pendiente' else 'Cerrado' end as estado
from cxp;

-- ---------------------------------------------------------------------------
-- DASHBOARD (una sola consulta responde "cuánto hay, quién debe, cuánto se ganó")
-- ---------------------------------------------------------------------------
create view v_dashboard as
select
  (select saldo from v_cajas where caja = 'Caja COP')  as saldo_cop,
  (select saldo from v_cajas where caja = 'Caja USD')  as saldo_usd,
  (select saldo from v_cajas where caja = 'Caja USDT') as saldo_usdt,
  (select coalesce(sum(saldo_pendiente), 0) from v_cxc where moneda = 'COP')  as cxc_pendiente_cop,
  (select coalesce(sum(saldo_pendiente), 0) from v_cxc where moneda = 'USDT') as cxc_pendiente_usdt,
  (select coalesce(sum(monto), 0) from v_cxp where moneda = 'COP'  and estado = 'Pendiente') as cxp_pendiente_cop,
  (select coalesce(sum(monto), 0) from v_cxp where moneda = 'USDT' and estado = 'Pendiente') as cxp_pendiente_usdt,
  (select coalesce(sum(utilidad_cop), 0) from v_operaciones) as utilidad_acumulada_cop;

-- ---------------------------------------------------------------------------
-- ESTADO DE CONVERSACIÓN DEL BOT (necesario porque el bot vive en una función
-- serverless sin memoria entre mensajes — cada paso de la conversación se
-- guarda aquí hasta que el usuario confirma).
-- ---------------------------------------------------------------------------
create table bot_conversaciones (
  chat_id bigint primary key,
  flujo text,               -- 'nuevo_movimiento' | 'nueva_operacion' | 'nuevo_abono'
  paso text,
  datos jsonb default '{}',
  actualizado_en timestamptz default now()
);
