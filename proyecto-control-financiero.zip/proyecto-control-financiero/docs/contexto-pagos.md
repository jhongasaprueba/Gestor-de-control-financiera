# Contexto de Pagos y Conciliación
Describe cómo opera el proceso de pagos internacionales de la empresa: canal, procesadores, comisiones y cómo se generan y cierran las deudas de cada operación.
Usar cuando: necesites entender o registrar el flujo de pago de una operación de compra/venta de mercancía, calcular utilidad, o dar seguimiento a una deuda relacionada con pagos.

## Modelo de negocio
- La empresa compra mercancía a un fabricante en China (y también en Estados Unidos) y la vende localmente. No importa ni exporta mercancía.
- Flujo comercial: cotización → proforma → aceptación → pago al fabricante → conciliación.
- La utilidad proviene de: volumen, diferencial cambiario (COP↔USDT↔USD) y comisiones ocasionales.

## Canal de pago
- El único canal para pagos internacionales es **SWIFT**. No existe un canal "BINER"; cualquier mención a ese término es un error de digitación por "SWIFT".
- Los pagos también pueden liquidarse directamente en USDT, sin pasar por SWIFT, cuando resulta más barato.
- Antes de ejecutar el pago se elige el canal más económico entre USDT directo y SWIFT, cotizando el costo de cada uno para esa operación puntual.

## Procesadores de pago
- Ver contexto-entidades.md para la lista de procesadores y proveedores de USDT.
- Ambos procesadores manejan exclusivamente pagos por SWIFT.
- Reciben USDT de la empresa y con eso ejecutan el pago internacional (p. ej. al fabricante en China).
- El costo de procesamiento está entre 0% y 1%, y se cotiza operación por operación; no es un porcentaje fijo.
- El mismo procesador que ejecuta el pago es quien entrega los códigos de rastreo **MT103** y **UTR** que confirman su ejecución.

## Ciclo de deudas de una operación típica
Una operación de compra/venta puede generar hasta tres deudas simultáneas:

1. **Empresa → Proveedor de USDT**: se genera **siempre** al comprar USDT, aunque el pago al proveedor sea casi inmediato — es un pasivo momentáneo, no exclusivo de compras a crédito. Se cierra cuando la empresa transfiere el pago correspondiente al proveedor.
   - Nota: contexto-operaciones.md (Operación tipo 3, "Compra de USDT a crédito") describe el caso en que este pasivo se sostiene por más tiempo antes de saldarse. No es un tipo de deuda distinto — es la misma deuda con un plazo de cierre más largo.
2. **Procesador → Empresa**: se genera al enviar el USDT al procesador para que ejecute el pago al fabricante. Se cierra cuando el procesador confirma la ejecución mediante el código MT103/UTR.
3. **Cliente → Empresa**: se genera al vender la mercancía al cliente; puede quedar en COP o en USDT. Se cierra cuando el cliente paga.

## Mapeo a plan de cuentas
Ver contexto-plan-cuentas.md para el detalle completo. Cada deuda del ciclo corresponde a:
- Empresa → Proveedor de USDT: pasivo "Proveedores USDT".
- Procesador → Empresa: activo "Pagos en tránsito con procesador" (pago enviado al procesador, aún no confirmado con MT103/UTR).
- Cliente → Empresa: activo "Cuentas por cobrar".

## Cálculo de utilidad
La empresa cotiza dos tasas distintas por operación: una de **compra** de USDT (costo para la empresa) y una de **venta** al cliente (precio cobrado). La utilidad se calcula de dos formas, según cómo se cotizó la operación:

**A. Cotización en pesos (COP)**
Utilidad = (monto en COP cobrado al cliente) − (costo en COP de comprar el USDT, incluyendo el costo del procesador).

Ejemplo:
- Compra de 30.000 USDT a 3.000 COP/USD, costo de envío 0,5% → costo total: 30.000 × 3.000 × 1,005 = 90.450.000 COP.
- Venta al cliente a 3.100 COP/USD → 30.000 × 3.100 = 93.000.000 COP.
- Utilidad = 93.000.000 − 90.450.000 = 2.550.000 COP.

**B. Cotización en USDT**
La empresa cobra una comisión fija al cliente sobre el monto en USDT (p. ej. 1%). Si el costo real del procesador es menor (p. ej. 0,5%), la diferencia (en este ejemplo 0,5%) es la utilidad neta.

## Tipo de cambio
- Las tasas de compra y venta (COP↔USDT, COP↔USD) se cotizan **manualmente**, operación por operación. No existe actualmente una tasa de referencia diaria fija.

## Roles
- Actualmente **una sola persona** ejecuta todo el proceso: cotización, pago y conciliación. No hay separación de roles ni montos que requieran aprobación adicional definidos por ahora.

## Control y SLA
- No existe actualmente un SLA definido para conciliar un pago ni para dar seguimiento a un pago rechazado (ver Operación tipo 5 en contexto-operaciones.md). Se maneja caso por caso hasta que se defina una política.

## Qué NO hace esta área
- No se importa ni exporta mercancía físicamente.
- No existe el canal "BINER" (error de digitación por SWIFT).
- No se maneja actualmente aprobación jerárquica ni separación de roles entre cotización, pago y conciliación.
