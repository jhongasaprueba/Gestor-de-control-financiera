# FAQ de Pagos y Conciliación
Preguntas frecuentes sobre el proceso de pago, comisiones y deudas generadas en una operación de compra/venta.
Usar cuando: necesites resolver una duda puntual sobre cómo se procesa, cotiza o concilia un pago.

### ¿Por qué canal se envían los pagos internacionales?
Únicamente por SWIFT, a través de dos procesadores: Facu o Richi.

### ¿Los procesadores manejan pagos en USDT directo, además de SWIFT?
No. Facu y Richi manejan exclusivamente SWIFT. Reciben USDT de la empresa y con eso ejecutan el pago SWIFT al destinatario final (p. ej. el fabricante en China).

### ¿Quién entrega el comprobante de que un pago se ejecutó?
El mismo procesador (Facu o Richi) entrega los códigos MT103 y/o UTR.

### ¿Qué deudas genera una operación típica?
Hasta tres: (1) la empresa le debe al proveedor de USDT, (2) el procesador le debe a la empresa la ejecución del pago, y (3) el cliente le debe a la empresa (en COP o en USDT).

### ¿Cuándo se cierra cada deuda?
- Procesador → Empresa: cuando se confirma que el pago llegó (MT103/UTR).
- Cliente → Empresa: cuando el cliente paga.
- Empresa → Proveedor de USDT: cuando la empresa transfiere el pago correspondiente al proveedor.

### ¿Cómo se calcula la utilidad de una operación?
Depende de cómo se cotizó:
- En pesos: utilidad = monto cobrado al cliente − costo total de comprar el USDT (incluyendo comisión del procesador).
- En USDT: utilidad = comisión cobrada al cliente − costo real del procesador.

### ¿La tasa de cambio es fija?
No. Se cotiza manualmente en cada operación; no existe una tasa de referencia diaria.

### ¿Existe un plazo definido para conciliar un pago o dar seguimiento a un rechazo?
No, todavía no existe un SLA definido. Se maneja caso por caso.

### ¿Quién ejecuta el proceso completo (cotización, pago, conciliación)?
Actualmente una sola persona. No hay separación de roles ni aprobaciones por monto definidas por ahora.
