# Glosario de Pagos y Conciliación
Contiene los términos, acrónimos y variantes incorrectas propios del proceso de pagos internacionales, que no están ya cubiertos en glosario-general.md.
Usar cuando: tengas dudas sobre un término usado en contexto-pagos.md o en el registro de una operación de pago. Para términos generales del negocio (COP, USD, USDT, Conciliación, Diferencial cambiario, etc.), ver glosario-general.md.

- **SWIFT**: red bancaria internacional usada para transferencias en dólares (USD). Es el único canal de pago internacional que usa la empresa. ⚠️ No confundir con "BINER" — es un error de digitación, ese canal no existe.
- **MT103**: código de mensaje SWIFT que confirma una transferencia internacional. Lo entrega el procesador de pago (Facu o Richi) como comprobante de ejecución.
- **UTR** (Unique Transaction Reference): código de rastreo de una transacción, entregado por el procesador de pago junto con o en lugar del MT103.
- **Procesador de pago**: Facu y Richi. Reciben USDT de la empresa y ejecutan pagos internacionales exclusivamente por SWIFT.
- **Proveedor de USDT**: entidad a la que la empresa le compra USDT con COP. Ver contexto-entidades.md (Bayter, Lider, Roma, Rojo, Tello).
- **Comisión**: porcentaje adicional (0% a 1%) cobrado por el procesador de pago, o por la empresa al cliente, según cómo se cotice la operación (en pesos o en USDT).
- **Cotización manual**: modo actual de fijar tasas de compra/venta de USDT y USD; se hace operación por operación. No existe tasa de referencia diaria.
- **"Vintage"** ⚠️: término usado por error al referirse a proveedores; no tiene significado en el negocio. Evitar su uso; el término correcto es "proveedor de USDT" o "procesador de pago" según el contexto.
