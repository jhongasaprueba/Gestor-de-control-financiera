# Glosario General
## Usar cuando
Existan dudas sobre términos del negocio.

- COP: Peso colombiano.
- USD: Dólar estadounidense.
- USDT: Stablecoin.
- Caja: Saldo disponible en una moneda y ubicación.
- Proforma: Documento preliminar comercial.
- Conciliación: Verificación de ejecución de pago.
- Cuenta por cobrar: Dinero pendiente a favor.
- Cuenta por pagar: Dinero pendiente en contra.
- Diferencial cambiario: Ganancia por tasa de cambio.