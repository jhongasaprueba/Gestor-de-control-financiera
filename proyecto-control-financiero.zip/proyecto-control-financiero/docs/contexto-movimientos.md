# Catálogo de Movimientos
## Usar cuando
Debas registrar una transacción.

## Entradas
- Recaudo cliente
- Compra de USDT recibida
- Préstamo recibido

## Salidas
- Pago proveedor
- Compra mercancía
- Pago préstamo
- Envío a procesador

## Transferencias
- COP a USD
- COP a USDT
- USD a USDT
- Entre cajas

Cada movimiento debe registrar fecha, tercero, moneda, monto y soporte.