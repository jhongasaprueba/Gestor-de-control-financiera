# Manual de Operaciones
## Usar cuando
Necesites documentar un caso operativo.

## Operación tipo 1
Cliente paga en COP, se compra USDT, se envía a procesador, se concilia.

## Operación tipo 2
Cliente entrega USDT, se envía a procesador, se concilia.

## Operación tipo 3
Compra de USDT a crédito.
Genera entrada a caja y cuenta por pagar.

## Operación tipo 4
Préstamo para financiar operación.
Genera entrada a caja y pasivo.

## Operación tipo 5
Pago rechazado.
Debe quedar registro de rechazo y seguimiento.