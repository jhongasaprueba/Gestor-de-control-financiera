# Contexto de Entidades
## Usar cuando
Necesites entender participantes del negocio.

## Cliente
Compra mercancía o solicita gestión de pagos.

## Fabricante
Proveedor original de mercancía.

## Proveedor de USDT
Bayter, Lider, Roma, Rojo, Tello.

## Procesador de pago
Facu y Richi. Reciben USDT y ejecutan pagos internacionales.

## Prestamista
Entrega recursos financieros a la empresa.

## Deudor
Persona o entidad con obligaciones pendientes.