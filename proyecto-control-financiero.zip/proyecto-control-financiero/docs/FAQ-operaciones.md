# FAQ Operaciones
## Usar cuando
Necesites responder preguntas frecuentes.

### ¿Qué se registra primero?
La operación y origen de fondos.

### ¿Qué ocurre al comprar USDT?
Entrada a caja USDT y posible cuenta por pagar.

### ¿Qué ocurre cuando paga el cliente?
Entrada de fondos y reducción de cuenta por cobrar.

### ¿Qué debe poder responder el sistema?
Cuánto dinero hay, dónde está, quién debe y cuánto se ha ganado.