# Manual Operativo y Financiero de la Empresa
## Descripción
Documento maestro del negocio.
## Usar cuando
Se necesite entender la empresa completa.

### Identidad
La empresa compra mercancía en Asia y Estados Unidos para venderla localmente. Utiliza COP, USD y USDT para financiar y ejecutar operaciones.

### Modelo de negocio
Fuentes de utilidad:
- Margen comercial de mercancía.
- Diferencial cambiario.
- Comisiones ocasionales.

### Entidades
Clientes, fabricantes, proveedores de USDT, procesadores de pago, prestamistas y deudores.

### Flujo general
Solicitud → Cotización → Aceptación → Obtención de liquidez → Pago → Conciliación → Cierre.

### Monedas
COP, USD, USDT.

### Control financiero
- Cajas.
- Cuentas por cobrar.
- Cuentas por pagar.
- Préstamos.
- Utilidades.
- Documentación.

### Regla principal
Todo movimiento debe ser trazable desde origen hasta destino.