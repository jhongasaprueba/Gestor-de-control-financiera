# Plan de Cuentas Operativo
## Usar cuando
Necesites clasificar activos, pasivos, ingresos y gastos.

## Activos
- Caja COP
- Caja USD
- Caja USDT
- Cuentas por cobrar
- Préstamos otorgados
- Pagos en tránsito con procesador (USDT enviado a Facu/Richi para ejecutar un pago SWIFT, pendiente de confirmación por MT103/UTR)

## Pasivos
- Proveedores USDT
- Préstamos recibidos
- Obligaciones pendientes

## Ingresos
- Margen comercial
- Diferencial cambiario
- Comisiones

## Gastos
- Comisiones procesadores
- Fees blockchain
- Costos bancarios